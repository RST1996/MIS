<META HTTP-EQUIV="REFRESH" CONTENT="3; url=../">
<center>
<img src="../alt-img/loading.gif" /><br />
 <h1> <em>You will be redirected to homepage in few seconds..</em></h1>
  <h4><em>If not Then <a href="../index.php">Click here</a></em></h4>
</center>
